import os
from flask import Flask


app = Flask(__name__, static_url_path="")


from blueprints.views import *
from blueprints.internal import *


app.register_blueprint(views)
app.register_blueprint(internal)


if __name__ == "__main__":
    app.run()
