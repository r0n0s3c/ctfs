const { exit } = require("process");
const puppeteer = require("puppeteer");


const url = process.argv[2];
const outputPath = process.argv[3];


async function screenshot(url) {
    const browser = await puppeteer.launch({
        defaultViewport: {width: 1080, height: 1080},
        args: ['--no-sandbox', '--headless']
    });
    const page = await browser.newPage();
    try {
        await page.goto(url);
    } catch (e) {
        console.log(e);
    }

    try {
        await page.screenshot({ path: outputPath, omitBackground: true });
        console.log("glb-merge: " + outputPath);
        page.close();
        exit();
    }
    catch (e) {
        console.log(e);
    }
}

screenshot(url);
