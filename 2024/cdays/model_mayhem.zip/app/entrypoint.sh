#!/usr/bin/env bash

WORKERS=4
PORT=${PORT:-8080}

exec gunicorn --bind :$PORT --workers $WORKERS --threads 8 app:app
