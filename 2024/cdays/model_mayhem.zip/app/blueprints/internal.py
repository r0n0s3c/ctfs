from flask import Blueprint, render_template, request, jsonify, send_from_directory, redirect
import uuid, subprocess, base64
from functools import wraps

from app import app


internal = Blueprint("internal", __name__, url_prefix="/internal")


def internal_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if request.remote_addr != "127.0.0.1":
            return redirect("/")
        return f(*args, **kwargs)
    return decorated_function


@internal.route("/merge/<filename>", methods=["GET"])
@internal_required
def internal_merge(filename):
    text = request.args.get("text")
    if not text:
        return "No text provided"
    
    return render_template("template.html", filename=filename, text=text)


@internal.route("/image/<filename>", methods=["GET"])
@internal_required
def internal_image(filename):
    if "/" in filename or "\\" in filename or ".." in filename:
        return "What are you trying to do?"
    
    if not filename.endswith(".png"):
        return "Invalid file extension"
    
    return send_from_directory("./data/", filename)
