from flask import Blueprint, render_template, request, jsonify, send_from_directory
import uuid, subprocess, base64

from app import app


views = Blueprint("views", __name__)


@views.route("/", methods=["GET"])
def index():
    return render_template("index.html")


@views.route("/api/upload", methods=["POST"])
def upload():
    file = request.files["file"]
    if file.filename.split(".")[-1] not in ["glb"]:
        return jsonify({"success": False, "error": "Invalid file extension"})
    filename = str(uuid.uuid4()) + ".glb"
    file.save("./data/" + filename)
    return jsonify({"success": True, "filename": filename})


@views.route("/api/preview", methods=["POST"])
def preview():
    filename = request.json.get("filename")
    if not filename:
        return jsonify({"success": False, "error": "No filename provided"})
    
    if "/" in filename or "\\" in filename or ".." in filename:
        return jsonify({"success": False, "error": "What are you trying to do?"})
    
    input_path = "./data/" + filename
    output_filename = filename + ".png"
    output_path = "./data/" + output_filename
    
    subprocess.run(["screenshot-glb", "-i", input_path, "-o", output_path])
    
    try:
        with open(output_path, "rb") as f:
            data = f.read()
            data = "data:image/png;base64," + base64.b64encode(data).decode("utf-8")
            return jsonify({"success": True, "data": data, "filename": output_filename})
    except Exception as e:
        print(e)
        return jsonify({"success": False, "error": "Something went wrong"})


@views.route("/api/merge", methods=["POST"])
def merge():
    filename = request.json.get("filename")
    text = request.json.get("text")
    if not filename:
        return jsonify({"success": False, "error": "No filename provided"})
    
    if not text:
        return jsonify({"success": False, "error": "No text provided"})
    
    if len(text) > 100:
        return jsonify({"success": False, "error": "Text is too long"})
    
    if "/" in filename or "\\" in filename or ".." in filename:
        return jsonify({"success": False, "error": "What are you trying to do?"})
    
    output_filename = filename.split(".")[0] + "_merged.png"
    output_path = "./data/" + output_filename

    url = "http://127.0.0.1:8080/internal/merge/" + filename + "?text=" + text
    subprocess.run(["node", "node/glb-merge.js", url, output_path])
    
    try:
        with open(output_path, "rb") as f:
            data = f.read()
            data = "data:image/png;base64," + base64.b64encode(data).decode("utf-8")
            return jsonify({"success": True, "data": data, "filename": output_filename})
    except Exception as e:
        print(e)
        return jsonify({"success": False, "error": "Something went wrong"})
